#!/bin/sh
autoreconf -vi
