#ifndef _CLASSES_H
#define _CLASSES_H

#include "utils.h"


class site {
public:
	int chr;
	string id;
	int pos;
	string ref;
	string alt;
	int idx;
	int idx_chunk;
	int idx_in_chunk;

	//C/D
	site(int chr, string & id, int pos, string & r, string & a, int idx) {
		this->chr = chr;
		this->id = id;
		this->pos = pos;
		this->ref = r;
		this->alt = a;
		this->idx = idx;
		idx_chunk = -1;
		idx_in_chunk = -1;
	}

	~site() {
	};

	//M
	int strand(string & r, string & a, bool flip) {
		if (ref == r && alt == a) return 1;
		if (flip && ref == a && alt == r) return -1;
		else return 0;
	};
};

class site_set {
public:
	vector < site * > vec_site;
	multimap < int, site *> map_site;
	bool allowsFlip;

	//C/D
	site_set() {};
	~site_set() {};

	//M
	int size() {
		return vec_site.size();
	}

	void push(site * s) {
		vec_site.push_back(s);
		map_site.insert ( std::pair< int, site * >( s->pos , s));
	}

	site * get(int p, string & r, string & a, bool & flip) {
		pair < multimap < int, site *>::iterator, multimap < int, site *>::iterator > seqM = map_site.equal_range(p);
		for (multimap < int, site *>::iterator itM = seqM.first; itM != seqM.second; ++itM) {
			int strand = itM->second->strand(r, a, allowsFlip);
			if (strand == -1) {
				flip = true;
				return itM->second;
			} else if (strand == 1) {
				flip = false;
				return itM->second;
			}
		}
		return NULL;
	}
};

class chunk {
public:
	string id;
	vector < int > mappingS;
	vector < vector < bool > > H;
	vector < bool > switches;

	chunk(int n, char *);
	~chunk();

	void assemble(chunk *);

	void readChunk(char *, char *);
};

class data {
public:
	site_set M;
	vector < string > I;
	vector < chunk * > C;
	set < string > S;

	data();
	~data();

	void readMap(char *);
	void readChunk(char *);
	void readScaffold(char *);
	void assemble();
	void writeHaplotypes(char *, char *);
};

#endif



