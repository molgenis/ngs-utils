#define _GLOBAL


#include "classes.h"

int main (int argc, char ** argv) {

	char * ohap = NULL;
	char * osam = NULL;
	vector < char * > chunks;
	char * vcf = NULL;
	char * scaf = NULL;
	bool flip = false;

	for (int a = 1; a < argc; a ++) {
		if (strcmp(argv[a], "--scaffold") == 0) { scaf = argv[a+1]; };
		if (strcmp(argv[a], "--output") == 0) { ohap = argv[a+1]; osam = argv[a+2]; };
		if (strcmp(argv[a], "--vcf") == 0) { vcf = argv[a+1];};
		if (strcmp(argv[a], "--flip") == 0) { flip = true;};
		if (strcmp(argv[a], "--chunks") == 0) {
			int cpt = a + 1;
			while (cpt >= 0) {
				if (argv[cpt][0] == '-') cpt = -1;
				else { chunks.push_back(argv[cpt]); cpt ++; }
			}
		}
	}

	if (vcf == NULL) { cout << "Missing option --vcf" << endl; exit(1);}
	else cout << "VCF :\t[" << vcf << "]" << endl;

	if (chunks.size() == 0) { cout << "Missing option: --chunks" << endl; exit(1);}
	else cout << "Chunks :\t" << chunks.size() << " haplotype files" << endl;

	if (scaf != NULL) cout << "Scaffold :\t[" << scaf << "]" << endl;

	if (ohap == NULL) { cout << "Missing option: --output" << endl; exit(1);}
	else cout << "Output :\t[" << ohap << "] [" << osam << "]" << endl;


	data D;
	D.M.allowsFlip = flip;

	D.readMap(vcf);
	if (scaf != NULL) D.readScaffold(scaf);
	for (int c = 0 ; c < chunks.size() ; c ++) D.readChunk(chunks[c]);
	D.assemble();
	D.writeHaplotypes(ohap, osam);

	return 0;
}
