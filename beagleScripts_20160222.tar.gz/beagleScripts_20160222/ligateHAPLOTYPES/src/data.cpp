#include "classes.h"

data::data() {
}


data::~data() {
	I.clear();
	for (int c = 0 ; c < C.size() ; c++) delete C[c];
	C.clear();
}

void data::readMap(char * vcf) {
	vector < string > tok;
	string buffer;

	cout << "Reading site map in [" << vcf << "]" << endl;
	ifile fd(vcf);
	while (getline(fd, buffer, '\n')) {
		if (buffer[0] == '#' && buffer[1] == 'C' && buffer[2] == 'H' && buffer[3] == 'R') {
			tok = sutils::tokenize(buffer, "\t");
			for (int t = 9 ; t < tok.size() ; t++) I.push_back(tok[t]);
			cout << "  * #inds=" << I.size() << endl;
		} else if (buffer[0] != '#') {
			tok = sutils::tokenize(buffer, "\t", 5);
			vector < string > alleles_alt = sutils::tokenize(tok[4], ",");
			if (alleles_alt[0] != "." && alleles_alt[0] != "0" && alleles_alt.size() == 1)
				M.push(new site (atoi(tok[0].c_str()), tok[2], atoi(tok[1].c_str()), tok[3], tok[4], M.size()));
		}
	}
	fd.close();
	cout << "  * #sites=" << M.size() << endl;
}

void data::readChunk(char * fhap) {
	vector < string > tok;
	string buffer;

	cout << "Reading haplotypes in [" << fhap << "]"; cout.flush();
	chunk * c = new chunk(I.size(), fhap);
	int n_site = 0;
	ifile fd (fhap);
	while (getline(fd, buffer, '\n')) {
		tok = sutils::tokenize(buffer, " ");
		assert (tok.size() == (I.size() * 2 + 5));

		bool flip = false;
		site * s = M.get(atoi(tok[2].c_str()), tok[3], tok[4], flip);
		if (s == NULL) {
			cout << "Not found = " << atoi(tok[2].c_str()) << " " << tok[3] << "  " << tok[4] << endl;
			exit(1);
		}
		c->mappingS.push_back(s->idx);
		c->H.push_back(vector < bool > (2 * I.size(), false));
		for (int t = 5; t < tok.size() ; t ++) if (tok[t] == "1") c->H.back()[t-5] = !flip;
		n_site ++;
	}
	cout <<"\t" << n_site << endl;
	C.push_back(c);
	fd.close();
}

void data::readScaffold(char * fsca) {
	vector < string > tok;
	string buffer;

	cout << "Reading scaffolded samples in [" << fsca << "]" << endl;
	ifile fd(fsca);
	while (getline(fd, buffer, '\n')) S.insert(buffer);
	fd.close();
	cout << "  * #scaff=" << S.size() << endl;
}

struct less_than_chunk {
	inline bool operator() (const chunk * c1, const chunk * c2) {
		return (c1->mappingS[0] < c2->mappingS[0]);
    }
};

void data::assemble() {
	cout << "Sorting the " << C.size() << " chunks of data" << endl;
	sort(C.begin(), C.end(), less_than_chunk());
	for (int c = 1 ; c < C.size() ; c++) {
		cout << "Assembling [" << C[c -1]->id << "] with [" << C[c]->id << "]" << endl;
		C[c]->assemble(C[c-1]);
	}
	cout << "Mapping sites to chunks" << endl;
	for (int c = 0 ; c < C.size() ; c++) {
		for (int l = 0 ; l < C[c]->mappingS.size() ; l ++) {
			if (C[c]->mappingS[l] >= 0) {
				M.vec_site[C[c]->mappingS[l]]->idx_chunk = c;
				M.vec_site[C[c]->mappingS[l]]->idx_in_chunk = l;
			}
		}
	}
	cout << "Checking mapping sites to chunks" << endl;
	for (int l = 0 ; l < M.vec_site.size() ; l ++)
		if (M.vec_site[l]->idx_chunk < 0)
			cout << "Site " << l << " with pos=" << M.vec_site[l]->pos << " is unmapped" << endl;
}

void data::writeHaplotypes(char * fhap, char * fsam) {
	cout << "Writing samples in [" << fsam << "]" << endl;
	ofile fds (fsam);
	fds << "ID_1 ID_2 missing" << endl << "0 0 0" << endl;
	for (int i = 0 ; i < I.size() ; i ++) fds << I[i] << " " << I[i] << " 0" << endl;
	fds.close();

	cout << "Writing haplotypes in [" << fhap << "]" << endl;
	ofile fdh (fhap);
	for (int s = 0 ; s < M.size() ; s ++) {
		fdh << M.vec_site[s]->chr << " " << M.vec_site[s]->id << " " << M.vec_site[s]->pos << " " << M.vec_site[s]->ref << " " << M.vec_site[s]->alt;
		for (int i = 0 ; i < I.size() ; i ++) {
			int idx_chunk = M.vec_site[s]->idx_chunk;
			int idx_in_chunk = M.vec_site[s]->idx_in_chunk;
			set < string > :: iterator itS = S.find(I[i]);
			if (C[idx_chunk]->switches[i] || itS != S.end())
				fdh << " " << C[idx_chunk]->H[idx_in_chunk][2 * i + 0] << " " << C[idx_chunk]->H[idx_in_chunk][2 * i + 1];
			else fdh << " " << C[idx_chunk]->H[idx_in_chunk][2 * i + 1] << " " << C[idx_chunk]->H[idx_in_chunk][2 * i + 0];
		}
		fdh << endl;
	}
	fdh.close();
}
