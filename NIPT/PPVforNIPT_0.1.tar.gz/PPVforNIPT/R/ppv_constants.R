#range of fetal percentages
fetal.low.wide <- 1
fetal.high.wide <- 23

fetal.low.narrow <- 6
fetal.high.narrow <- 18
