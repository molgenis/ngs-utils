Rscript ../../ChiCorrection.R \
../data/controlBins/ \
../CreateBins/output/GoldsStandards_bins_forward.csv \
tmp/ \
bestControlSet/merged_NIT20140001_F3_20140206_u0mm_subopt.BestControlSet.list.tsv \
forward \
merged_NIT20140001_F3_20140206_u0mm_subopt


Rscript ../../ChiCorrection.R \
../data/controlBins/ \
../CreateBins/output/GoldsStandards_bins_reverse.csv \
tmp/ \
bestControlSet/merged_NIT20140001_F3_20140206_u0mm_subopt.BestControlSet.list.tsv \
reverse \
merged_NIT20140001_F3_20140206_u0mm_subopt